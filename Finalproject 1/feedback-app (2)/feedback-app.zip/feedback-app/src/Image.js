import React from "react";  
import img1 from './images/feedback.jpeg';

function Image(){
    return(
        <div>
            < img src={img1} alt=""/>
        </div>
    )
}