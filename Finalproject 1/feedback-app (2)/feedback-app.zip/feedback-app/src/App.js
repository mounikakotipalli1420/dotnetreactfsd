import React, { useState } from 'react';
import Welcome from './Components/Welcome';
import Login from './Components/Login';
import RegisterUser from './Components/RegisterUser';
import CreateSurvey from './Components/CreateSurvey';
import SurveySubmissionComponent from './Components/SurveySubmissionComponent';
import SurveyDropdown from './Components/SurveyDropdown';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';

const NavBar = ({ isLoggedIn, isLoginSelected, isRegisterSelected }) => {
  return (
    <nav>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        {isLoggedIn && (
          <>
            <li>
              <Link to="/surveys">Surveys</Link>
            </li>
            <li>
              <Link to="/create-survey">Create Survey</Link>
            </li>
          </>
        )}
        {!isLoggedIn && !isLoginSelected && !isRegisterSelected && (
          <>
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/register">Register</Link>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
};

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoginSelected, setIsLoginSelected] = useState(false);
  const [isRegisterSelected, setIsRegisterSelected] = useState(false);
  const [selectedSurvey, setSelectedSurvey] = useState('');
  const navigate = useNavigate();

  const handleLoginSelect = () => {
    setIsLoginSelected(true);
    setIsRegisterSelected(false);
  };

  const handleRegisterSelect = () => {
    setIsLoginSelected(false);
    setIsRegisterSelected(true);
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
    setIsLoginSelected(false);
    setIsRegisterSelected(false);
    navigate('/'); // Redirect to home after login
  };

  const handleRegister = () => {
    setIsLoggedIn(true);
    setIsLoginSelected(false);
    setIsRegisterSelected(false);
    navigate('/'); // Redirect to home after registration
  };

  const handleSurveySelect = (survey) => {
    setSelectedSurvey(survey);
  };

  return (
    <Router>
      <div className="App">
        <NavBar isLoggedIn={isLoggedIn} isLoginSelected={isLoginSelected} isRegisterSelected={isRegisterSelected} />

        <hr />

        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route
            path="/login"
            element={
              !isLoggedIn && !isLoginSelected && !isRegisterSelected ? (
                <Login onLogin={handleLogin} />
              ) : null
            }
          />
          <Route
            path="/register"
            element={
              !isLoggedIn && !isLoginSelected && !isRegisterSelected ? (
                <RegisterUser onRegister={handleRegister} />
              ) : null
            }
          />
          <Route
            path="/surveys"
            element={
              isLoggedIn ? (
                <div>
                  <SurveyDropdown onSelectSurvey={handleSurveySelect} />
                  <SurveySubmissionComponent selectedSurvey={selectedSurvey} />
                </div>
              ) : null
            }
          />
          <Route
            path="/create-survey"
            element={
              isLoggedIn ? (
                <CreateSurvey />
              ) : null
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
