﻿namespace FeedBackAppA.Interfaces
{
    public interface IAnswerRepository
    {
    }
}
