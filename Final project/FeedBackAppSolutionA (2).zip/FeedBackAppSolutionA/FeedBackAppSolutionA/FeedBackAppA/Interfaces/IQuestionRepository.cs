﻿namespace FeedBackAppA.Interfaces
{
    public interface IQuestionRepository
    {
    }
}
