﻿namespace FeedBackAppA.Models
{
    public class QuestionResponse
    {
        public int QuestionResponseId { get; set; }
        public int QuestionId { get; set; }
       // public Question Question { get; set; }
        public int AnswerId { get; set; }
       // public Answer Answer { get; set; }
    }
}
