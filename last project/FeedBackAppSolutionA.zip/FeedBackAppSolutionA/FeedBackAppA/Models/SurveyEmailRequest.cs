﻿namespace FeedBackAppA.Models
{
    public class SurveyEmailRequest
    {
        public int SurveyNumber { get; set; }
        public string UserEmail { get; set; }
    }
}
